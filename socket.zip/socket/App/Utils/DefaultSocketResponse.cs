using System.Text;

namespace socket.App.Utils
{
    public static class DefaultSocketResponse
    {
        public static byte[] GotIt => Encoding.ASCII.GetBytes("Got your message ;)");
        
    }
}
