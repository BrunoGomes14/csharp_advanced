using System;


namespace socket
{
    public abstract class SocketOptions
    {
        public const string EOF = "<EOF>";
        public const string EOF_CLOSE = "<EOF:CLOSE>";

    }
}